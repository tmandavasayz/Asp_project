#define _GNU_SOURCE -std=gnu99

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <string.h>

void handle_client(int, int);

int main(int argc, char *argv[])
{
    int sd, client, status;
    int portNumber=3000;
    struct sockaddr_in servAdd; // client socket address

    if ((sd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        fprintf(stderr, "Cannot create the socket\n");
        exit(1);
    }
    sd = socket(AF_INET, SOCK_STREAM, 0);
    servAdd.sin_family = AF_INET;
    servAdd.sin_addr.s_addr = htonl(INADDR_ANY);
    servAdd.sin_port = htons((uint16_t)portNumber);

    bind(sd, (struct sockaddr *)&servAdd, sizeof(servAdd));
    listen(sd, 5);

    while (1)
    {
        printf("Waiting for a client to chat with\n");
        client = accept(sd, NULL, NULL);
        printf("Got a client, start chatting\n");

        if (!fork())
        {
            int pid = getpid();
            handle_client(client,pid);
        }

        // close(client);
        waitpid(0, &status, WNOHANG);
    }
}

void handle_client(int sd,int pid)
{
    char pat[255], content[1000], file2[255],message[255], result[1000] = "";

    int n, m;
    char *num;
    char serverFile[255] = "server.txt";
    
    read(sd, pat, 255);
    write(sd, "pat received", strlen("pat received") + 1);

    read(sd, file2, 255);
    write(sd, "File received", strlen("File received") + 1);

    read(sd, content, 1000);
    write(sd, "file Content received", strlen("file Content received") + 1);
    FILE *fp = fopen(serverFile, "w");
    if (fp != NULL)
    {
        fputs(content, fp);
        fclose(fp);
    }

    char buf[1024];
    sprintf(buf, "grep -w --color=always %s -e '^' -e %s ", serverFile, pat);
    char line[1024];

    fp = popen(buf, "r");
    if (fp == NULL)
    {
        printf("Failed to run command\n");
        exit(1);
    }

    while (fgets(line, sizeof(line), fp) != NULL)
    {
        strcat(result, file2);
        strcat(result," : ");
        strcat(result,line);
    }
    pclose(fp);
    remove(serverFile);
    write(sd, result, strlen(result) + 1);    
    exit(0);
}