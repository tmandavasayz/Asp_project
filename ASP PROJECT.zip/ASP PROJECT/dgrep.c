#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <assert.h>

char *fileRead(char *file)
{
  FILE *f;
  if ((f = fopen(file, "rt")) == NULL)
  {
    printf("Error in opening the file\n");
    exit(1);
  }
  assert(f);
  fseek(f, 0, SEEK_END);
  long length = ftell(f);
  fseek(f, 0, SEEK_SET);
  char *buffer = (char *)malloc(length + 1);
  buffer[length] = '\0';
  fread(buffer, 1, length, f);
  fclose(f);
  return buffer;
}

int main(int argc, char *argv[])
{
  char message[1000];
  int server, portNumber = 3000, pid, n;
  char ip_add[50] = "127.0.0.1";
  char pat[255];
  char file1[255];
  char file2[255];

  struct sockaddr_in servAdd; 

  if (argc != 4)
  {
    printf("Call model: %s <IP Address> <Port Number>\n", argv[0]);
    exit(0);
  }

  if ((server = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
    fprintf(stderr, "Cannot create a socket\n");
    exit(1);
  }

  servAdd.sin_family = AF_INET;
  strcpy(pat, argv[1]);
  strcpy(file1, argv[2]);
  strcpy(file2, argv[3]);
  servAdd.sin_port = htons((uint16_t)portNumber);

  if (inet_pton(AF_INET, ip_add, &servAdd.sin_addr) < 0)
  {
    fprintf(stderr, " inet_pton() has failed\n");
    exit(2);
  }

  if (connect(server, (struct sockaddr *)&servAdd, sizeof(servAdd)) < 0)
  {
    fprintf(stderr, "connect() has failed, exiting\n");
    exit(3);
  }

  char buf[1024];
  if(access(file1, F_OK)!=-1){
    sprintf(buf, "grep -w --color=always %s -e '^' -e %s ", file1, pat);
  }
  else{
    printf("Error in opening the file\n");
    exit(1);
  }

  char *content = fileRead(file2);

  FILE *fp;
  char path[1024];

  fp = popen(buf, "r");
  if (fp == NULL)
  {
    printf("Failed to run the command\n");
    exit(1);
  }
  printf("From Client:\n");
  while (fgets(path, sizeof(path), fp) != NULL)
  {
    printf("%s : %s", file1, path);
  }

  pclose(fp);

  write(server, pat, strlen(pat) + 1);
  read(server, message, 255);
  write(server, file2, strlen(file2) + 1);
  read(server, message, 255);
  printf("From Server:\n");
  write(server, content, strlen(content) + 1);
  read(server, message, 255);
  read(server, message, 1000);
  fprintf(stderr,"%s", message);
}
